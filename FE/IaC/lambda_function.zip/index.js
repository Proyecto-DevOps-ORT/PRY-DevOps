const nodemailer = require('nodemailer');
const AWS = require('aws-sdk');

exports.handler = async (event) => {
    const bucketName = event.Records[0].s3.bucket.name;
    const objectKey = event.Records[0].s3.object.key;
    
    const emailFrom = process.env.EMAIL_FROM;
    const emailTo = process.env.EMAIL_TO;
    const emailPassword = process.env.EMAIL_PASSWORD;
    
    // Configura el transportador de nodemailer
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: emailFrom,
            pass: emailPassword
        }
    });

    // Configura el contenido del correo electrónico
    let mailOptions = {
        from: emailFrom,
        to: emailTo,
        subject: 'S3 Bucket Modification Notification',
        text: `S3 bucket '${bucketName}' has been modified.\nObject key: ${objectKey}`
    };

    // Envía el correo electrónico
    try {
        let info = await transporter.sendMail(mailOptions);
        console.log('Email sent: ' + info.response);
    } catch (error) {
        console.log('Error sending email: ' + error);
    }

    return {
        statusCode: 200,
        body: JSON.stringify('Email sent successfully!')
    };
};
